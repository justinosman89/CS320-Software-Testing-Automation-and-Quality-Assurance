import java.util.ArrayList;
import java.util.List;


public class ContactService {
	//list that stores contacts
	private List<Contact> contacts = new ArrayList<>();
	
	//method that adds new contact
	public void addContact(Contact contact) {
		//checks to see if any of the existing contacts equals contact ID as the one being added
		boolean isUnique = contacts.stream().noneMatch(c-> c.getContactID().equals(contact.getContactID()));
		//if true add contact
		if (isUnique) {
			contacts.add(contact);
		}
	}
	
	//method to delete contact using contactID
	public void deleteContact(String contactID) {
		//execute code that will delete a contacts using that contacts ID
		contacts.removeIf(contact -> contact.getContactID().equals(contactID));
	}
	
	//method to update contact using all contacts specifics
	public void updateContact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
		//search and find the contact using its ID and then update the contacts specifics
		for (Contact contact : contacts) {
			//if contactID from list equals contactID parameter, then update the specifics
			if (contact.getContactID().equals(contactID)) {
				contact.setFirstName(firstName);
				contact.setLastName(lastName);
				contact.setPhoneNumber(phoneNumber);
				contact.setAddress(address);
				//ends loop once correct ID is found
				break;
			}
		}
	}
	
	//method to get list of contacts
	public List<Contact> getContacts(){
		return contacts;
	}
}
