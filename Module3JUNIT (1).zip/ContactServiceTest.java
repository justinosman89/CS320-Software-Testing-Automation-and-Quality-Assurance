import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactServiceTest {

	@Test
	public void addContactTest() {
		//create new instance for testing
		ContactService service = new ContactService();
		//dummy contact to use for test
		Contact contact = new Contact("10987", "Kobe", "Bryant", "5705550823", "43 West Main St");
		//test addContact method
		service.addContact(contact);
		
		//check to make sure the contact was added
		assertTrue(service.getContacts().contains(contact));
	}
	
	@Test
	public void deleteContactTest() {
		//new instance for testing
		ContactService service = new ContactService();
		//dummy contact for testing
		Contact contact = new Contact("10987", "Kobe", "Bryant", "5705550823", "43 West Main St");
		
		//add contact to the service
		service.addContact(contact);
		//test deleteContact method
		service.deleteContact("10987");
		
		//check to make sure contact was deleted
		assertFalse(service.getContacts().contains(contact));	
	}
	
	@Test
    public void testUpdateContact() {
        //create new instance for testing
		ContactService service = new ContactService();
		//dummy contact for testing
        Contact contact = new Contact("10987", "Kobe", "Bryant", "5705550823", "43 West Main St");
        
        //add contact to service
        service.addContact(contact);

        // test updateContact method
        service.updateContact("10987", "Vince", "Carter", "5705551515", "15 Highrise Lane");

        // Check if the specifics were updated
        assertEquals("Vince", contact.getFirstName());
        assertEquals("Carter", contact.getLastName());
        assertEquals("5705551515", contact.getPhoneNumber());
        assertEquals("15 Highrise Lane", contact.getAddress());
    }

}
