import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactTest {

	@Test
	public void validContactTest() {
		//create new contact instance for test
		Contact contact = new Contact("10987", "Kobe", "Bryant", "5705550823", "43 West Main St");
		//check that contact specifics are correctly set
		assertEquals("10987", contact.getContactID());
		assertEquals("Kobe", contact.getFirstName());
		assertEquals("Bryant", contact.getLastName());
		assertEquals("5705550823", contact.getPhoneNumber());
		assertEquals("43 West Main St", contact.getAddress());
	}
	
	@Test
	public void nonValidContactTest() {
		//test for non-valid contacts, in this case should return null because of length lastName
		Contact contact = new Contact("10987", "Kobe", "Bryantthebesttoeverdoitalltime", "5705550823", "43 West Main St");
		//check if instance is null
		assertNull(contact);
	}
	
	@Test
	public void updateContactTest() {
		//create contact instance for testing
		Contact contact = new Contact("10987", "Kobe", "Bryant", "5705550823", "43 West Main St");
		//update contact specifics
		contact.setFirstName("Vince");
		contact.setLastName("Carter");
		contact.setPhoneNumber("5705551515");
		contact.setAddress("15 Highrise Lane");
		
		//check to make sure specifics were correctly updated
		assertEquals("Vince", contact.getFirstName());
		assertEquals("Carter", contact.getLastName());
		assertEquals("5705551515", contact.getPhoneNumber());
		assertEquals("15 Highrise Lane", contact.getAddress());
	}

}
